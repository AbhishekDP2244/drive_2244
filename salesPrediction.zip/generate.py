import numpy as np
import pandas as pd

def generate(n=3000, seed=42, noise_std=4200, nonlin_weight=1.0,
             w_marketing=1.0, w_footfall_int=1.0, w_competitor=1.0, w_emp_holiday=1.0):
    rng = np.random.default_rng(seed)

    store_type = rng.choice(['A', 'B', 'C'], size=n, p=[0.45, 0.35, 0.20])
    region = rng.choice(['North', 'South', 'East', 'West'], size=n)

    # Cluster-friendly base signal per store_type (creates natural clusters)
    type_base_size = {'A': 3500, 'B': 7000, 'C': 12000}
    type_base_emp  = {'A': 8,    'B': 18,   'C': 35}

    store_size = np.array([type_base_size[t] for t in store_type]) + rng.normal(0, 700, n)
    store_size = np.clip(store_size, 800, None)

    num_employees = np.array([type_base_emp[t] for t in store_type]) + rng.normal(0, 3, n)
    num_employees = np.clip(num_employees, 2, None).round()

    marketing_spend = rng.gamma(shape=2.2, scale=900, size=n)          # skewed spend
    footfall = 200 + 0.9 * store_size / 10 + rng.normal(0, 150, n)     # correlated w/ size
    footfall = np.clip(footfall, 50, None)

    avg_product_price = rng.normal(650, 120, n)
    avg_product_price = np.clip(avg_product_price, 150, None)

    competitor_distance_km = rng.exponential(scale=3.5, size=n)        # closer competitor = harder
    economic_index = rng.normal(100, 8, n)                             # macro index ~100
    holiday_flag = rng.choice([0, 1], size=n, p=[0.83, 0.17])

    # ---- True underlying sales-generating process (deliberately non-linear) ----
    linear_part = (
        4.1 * store_size / 10
        + 210 * num_employees
        + 3.4 * marketing_spend
        + 6.5 * footfall
        - 9.0 * avg_product_price / 10
        + 55 * economic_index
        + 3200 * holiday_flag
    )

    # Non-linear structure random forest can exploit, linear regression cannot:
    #  - threshold/saturation effect of marketing spend (diminishing returns)
    #  - interaction between footfall and store_type
    #  - non-monotonic competitor distance effect (sweet spot around 2-4km)
    #  - interaction between employees and holiday flag
    marketing_saturation = 4200 * np.sqrt(np.clip(marketing_spend, 0, None) / 100)
    type_multiplier = np.array([1.00 if t == 'A' else (1.18 if t == 'B' else 1.35) for t in store_type])
    footfall_interaction = (footfall * type_multiplier) * 4.2
    competitor_sweet_spot = -650 * (competitor_distance_km - 3.0) ** 2 + 2500
    employee_holiday_interaction = 180 * num_employees * holiday_flag

    nonlinear_part = (
        w_marketing * marketing_saturation
        + w_footfall_int * footfall_interaction
        + w_competitor * competitor_sweet_spot
        + w_emp_holiday * employee_holiday_interaction
    )

    base = 15000
    sales_revenue = base + linear_part + nonlin_weight * nonlinear_part
    sales_revenue += rng.normal(0, noise_std, n)   # irreducible noise
    sales_revenue = np.clip(sales_revenue, 1000, None)

    df = pd.DataFrame({
        'store_id': np.arange(1, n + 1),
        'store_type': store_type,
        'region': region,
        'store_size_sqft': store_size.round(1),
        'num_employees': num_employees.astype(int),
        'marketing_spend': marketing_spend.round(2),
        'footfall_daily': footfall.round(1),
        'avg_product_price': avg_product_price.round(2),
        'competitor_distance_km': competitor_distance_km.round(2),
        'economic_index': economic_index.round(2),
        'holiday_flag': holiday_flag,
        'sales_revenue': sales_revenue.round(2),
    })
    return df

if __name__ == '__main__':
    df = generate(
        n=3000, seed=42, noise_std=3500, nonlin_weight=1.0,
        w_marketing=0.4, w_footfall_int=1.3, w_competitor=1.8, w_emp_holiday=1.6
    )
    df.to_csv('/home/claude/salesdata/sales_prediction_dataset.csv', index=False)
    print(df.shape)
    print(df.head())
