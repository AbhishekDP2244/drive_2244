# Sales Prediction Dataset

A synthetic **retail store sales dataset** built specifically to (a) support both regression
and clustering exercises, and (b) demonstrate that **Random Forest outperforms Linear
Regression** on data with realistic non-linear effects and feature interactions.

## Files
| File | Purpose |
|---|---|
| `sales_prediction_dataset.csv` | The dataset — **3,000 rows x 12 columns** |
| `generate.py` | Script that generated the dataset (fully reproducible, seed=42) |
| `analysis.py` | Runs the LR vs RF comparison + KMeans clustering |
| `README.md` | This file |

**Why 3,000 rows?** Large enough for a Random Forest to learn stable non-linear
patterns and for a clean 80/20 train-test split (2,400 / 600), small enough to
train instantly on a laptop with no GPU. This is the sweet spot for a teaching /
portfolio-style dataset — bigger doesn't meaningfully improve the demo, smaller
makes the test set noisy.

## Columns

| Column | Type | Description |
|---|---|---|
| `store_id` | int | Row identifier |
| `store_type` | categorical (A/B/C) | Store format/size tier — good clustering & regression feature |
| `region` | categorical (North/South/East/West) | Geographic region |
| `store_size_sqft` | numeric | Store floor area |
| `num_employees` | numeric | Staff count |
| `marketing_spend` | numeric | Monthly marketing spend |
| `footfall_daily` | numeric | Average daily customer footfall |
| `avg_product_price` | numeric | Average product price at the store |
| `competitor_distance_km` | numeric | Distance to nearest competitor (km) |
| `economic_index` | numeric | Local economic index (~100 = baseline) |
| `holiday_flag` | binary (0/1) | Whether the period includes a holiday |
| `sales_revenue` | numeric | **Target variable** for regression |

## Why Random Forest beats Linear Regression here
The target was generated from a mostly-linear base **plus** several structures a
linear model cannot represent but a tree ensemble can:
- A **non-monotonic (U-shaped) effect** of `competitor_distance_km` on sales (a
  "sweet spot" around 3km — too close hurts, too far also hurts).
- An **interaction** between `footfall_daily` and `store_type` (footfall matters
  more in larger-format stores).
- An **interaction** between `num_employees` and `holiday_flag`.
- A **diminishing-returns (saturation)** effect of `marketing_spend`.

Linear Regression can only fit straight-line, additive relationships, so it
under-fits these patterns. Random Forest naturally captures thresholds,
curvature, and interactions via its tree splits.

## Results (test set, 20% holdout, seed=42)

| Model | R² | RMSE | MAE |
|---|---|---|---|
| Linear Regression | **≈0.70** | ≈9,390 | ≈7,550 |
| Random Forest | **≈0.93** | ≈4,510 | ≈3,440 |

Random Forest cuts RMSE by roughly **50%** and raises R² by about **0.23**
compared to Linear Regression — run `analysis.py` to reproduce these numbers
exactly (small variation is expected depending on library versions).

## Using it for clustering
Use the numeric store-profile columns for unsupervised segmentation:
```
store_size_sqft, num_employees, marketing_spend,
footfall_daily, avg_product_price, competitor_distance_km
```
`analysis.py` runs KMeans (k chosen via silhouette score) on standardized
versions of these columns and shows the resulting store segments largely
recover the underlying `store_type` structure (small/medium vs large format
stores) — a nice sanity check that the clusters are meaningful, not noise.

## Reproducing / regenerating
```bash
python generate.py    # writes sales_prediction_dataset.csv
python analysis.py    # prints regression + clustering results
```
You can adjust `noise_std` and the `w_*` weights inside `generate.py`'s
`generate()` function to make the LR-vs-RF gap larger or smaller.
