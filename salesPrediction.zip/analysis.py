"""
Sales Prediction Dataset - Full Analysis
1. Regression: Linear Regression vs Random Forest (R2, RMSE, MAE)
2. Clustering: KMeans on store profile features
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

df = pd.read_csv('/home/claude/salesdata/sales_prediction_dataset.csv')
print("Dataset shape:", df.shape)
print(df.dtypes)
print()

# ---------------- 1. REGRESSION: Linear Regression vs Random Forest ----------------
X = df.drop(columns=['sales_revenue', 'store_id'])
y = df['sales_revenue']

cat_cols = ['store_type', 'region']
pre = ColumnTransformer([
    ('cat', OneHotEncoder(drop='first'), cat_cols)
], remainder='passthrough')

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

lr = Pipeline([('pre', pre), ('model', LinearRegression())])
rf = Pipeline([('pre', pre), ('model', RandomForestRegressor(
    n_estimators=300, min_samples_leaf=2, random_state=42, n_jobs=-1))])

lr.fit(X_train, y_train)
rf.fit(X_train, y_train)

lr_pred = lr.predict(X_test)
rf_pred = rf.predict(X_test)

results = pd.DataFrame({
    'Model': ['Linear Regression', 'Random Forest'],
    'R2': [r2_score(y_test, lr_pred), r2_score(y_test, rf_pred)],
    'RMSE': [np.sqrt(mean_squared_error(y_test, lr_pred)), np.sqrt(mean_squared_error(y_test, rf_pred))],
    'MAE': [mean_absolute_error(y_test, lr_pred), mean_absolute_error(y_test, rf_pred)],
})
print("=== Regression Model Comparison ===")
print(results.to_string(index=False))
print()
print(f"Random Forest improves R2 by {(results.loc[1,'R2']-results.loc[0,'R2']):.3f} "
      f"and reduces RMSE by {(1 - results.loc[1,'RMSE']/results.loc[0,'RMSE'])*100:.1f}% vs Linear Regression.")
print()

# Feature importance from RF (helps explain WHY RF wins - non-linear interactions)
ohe = rf.named_steps['pre'].named_transformers_['cat']
cat_feature_names = list(ohe.get_feature_names_out(cat_cols))
num_feature_names = [c for c in X.columns if c not in cat_cols]
feature_names = cat_feature_names + num_feature_names
importances = rf.named_steps['model'].feature_importances_
fi = pd.Series(importances, index=feature_names).sort_values(ascending=False)
print("=== Random Forest Feature Importances (top 8) ===")
print(fi.head(8).to_string())
print()

# ---------------- 2. CLUSTERING: KMeans on store profile ----------------
cluster_features = ['store_size_sqft', 'num_employees', 'marketing_spend',
                     'footfall_daily', 'avg_product_price', 'competitor_distance_km']
Xc = df[cluster_features]
scaler = StandardScaler()
Xc_scaled = scaler.fit_transform(Xc)

best_k, best_score = None, -1
for k in range(2, 7):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(Xc_scaled)
    score = silhouette_score(Xc_scaled, labels)
    print(f"k={k}  silhouette={score:.3f}")
    if score > best_score:
        best_score, best_k = score, k

print(f"\nBest k by silhouette score: {best_k}")

km_final = KMeans(n_clusters=best_k, random_state=42, n_init=10)
df['cluster'] = km_final.fit_predict(Xc_scaled)

print("\n=== Cluster profile (mean values) ===")
print(df.groupby('cluster')[cluster_features + ['sales_revenue']].mean().round(1))
print("\n=== Cluster vs store_type crosstab (sanity check) ===")
print(pd.crosstab(df['cluster'], df['store_type']))

df.to_csv('/home/claude/salesdata/sales_prediction_dataset_with_clusters.csv', index=False)
print("\nSaved clustered dataset -> sales_prediction_dataset_with_clusters.csv")
