from datetime import datetime
from typing import Optional, Literal
from pydantic import BaseModel, Field

ReviewStatus = Literal["Approved", "Rejected", "Pending Manual Review"]


class PendingRequest(BaseModel):
    requestId: str
    status: str
    providerName: Optional[str] = None
    fileName: Optional[str] = None
    blobPath: Optional[str] = None
    createdAt: Optional[datetime] = None
    # extend with whatever other columns pendingOnboardingRequest actually has

    class Config:
        extra = "allow"  # tolerate additional DB columns not modeled explicitly


class ReviewUpdateRequest(BaseModel):
    status: ReviewStatus
    remarks: Optional[str] = Field(default="", description="Reason / mismatch details")


class ReviewRecord(BaseModel):
    requestId: str
    status: str
    remarks: Optional[str] = None
    reviewedAt: Optional[datetime] = None


class AuditLogEntry(BaseModel):
    requestId: str
    step: str
    result: str


class AuditLogRecord(AuditLogEntry):
    id: Optional[int] = None
    timestamp: Optional[datetime] = None
