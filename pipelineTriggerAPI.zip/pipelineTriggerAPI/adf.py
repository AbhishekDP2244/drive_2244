"""
Triggers an Azure Data Factory pipeline run.

Auth: uses the same DefaultAzureCredential as db.py — so this works with
Managed Identity in Azure, and falls back to `az login` / VS Code credentials
locally for testing. The identity needs the "Data Factory Contributor" role
(or a custom role with Microsoft.DataFactory/factories/pipelines/createrun/action)
on the target Data Factory.

Required environment variables:
    AZURE_SUBSCRIPTION_ID
    ADF_RESOURCE_GROUP
    ADF_FACTORY_NAME
    ADF_PIPELINE_NAME
"""

import os
from azure.identity import DefaultAzureCredential
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.core.exceptions import HttpResponseError

SUBSCRIPTION_ID = os.environ["AZURE_SUBSCRIPTION_ID"]
RESOURCE_GROUP = os.environ["ADF_RESOURCE_GROUP"]
FACTORY_NAME = os.environ["ADF_FACTORY_NAME"]
PIPELINE_NAME = os.environ["ADF_PIPELINE_NAME"]

_credential = DefaultAzureCredential()
_client = DataFactoryManagementClient(_credential, SUBSCRIPTION_ID)


def trigger_pipeline(file_name: str, extra_parameters: dict | None = None) -> str:
    """
    Starts a run of the configured ADF pipeline.

    Args:
        file_name: value passed as the pipeline's 'fileName' parameter
                   (must match a parameter name defined on the pipeline itself)
        extra_parameters: any additional pipeline parameters to pass through

    Returns:
        run_id (str) — use this to poll the run's status afterward

    Raises:
        HttpResponseError if ADF rejects the request (bad pipeline name,
        missing permissions, invalid parameters, etc.)
    """
    parameters = {"fileName": file_name}
    if extra_parameters:
        parameters.update(extra_parameters)

    try:
        run_response = _client.pipelines.create_run(
            resource_group_name=RESOURCE_GROUP,
            factory_name=FACTORY_NAME,
            pipeline_name=PIPELINE_NAME,
            parameters=parameters,
        )
        return run_response.run_id
    except HttpResponseError as e:
        # Surface ADF's actual error message rather than a generic SDK exception
        raise RuntimeError(f"ADF pipeline trigger failed: {e.message}") from e


def get_pipeline_run_status(run_id: str) -> str:
    """Fetch the current status of a pipeline run: Queued / InProgress / Succeeded / Failed / Cancelled."""
    run = _client.pipeline_runs.get(
        resource_group_name=RESOURCE_GROUP,
        factory_name=FACTORY_NAME,
        run_id=run_id,
    )
    return run.status
