"""
Database connection layer for Azure SQL.

Supports two auth modes controlled by the AUTH_MODE env var:
  - "managed_identity"  -> token-based auth, no password anywhere (recommended)
  - "sql_auth"          -> username/password (fine for local dev / quick POC)

Connections are created per-request via a FastAPI dependency, not pooled
globally, to avoid holding stale tokens across the Function's lifetime.
Azure SQL access tokens expire (~1 hour), so re-acquiring per request is safer
than caching a long-lived connection.
"""

import os
import struct
import pyodbc
from contextlib import contextmanager
from azure.identity import DefaultAzureCredential

SQL_SERVER = os.environ["SQL_SERVER"]          # e.g. yourserver.database.windows.net
SQL_DATABASE = os.environ["SQL_DATABASE"]      # e.g. OnboardingDB
AUTH_MODE = os.environ.get("AUTH_MODE", "managed_identity")  # or "sql_auth"
SQL_DRIVER = os.environ.get("SQL_DRIVER", "{ODBC Driver 18 for SQL Server}")

# Only required when AUTH_MODE == "sql_auth"
SQL_USER = os.environ.get("SQL_USER")
SQL_PASSWORD = os.environ.get("SQL_PASSWORD")

SQL_COPT_SS_ACCESS_TOKEN = 1256
_credential = DefaultAzureCredential() if AUTH_MODE == "managed_identity" else None


def _build_conn_str() -> str:
    base = (
        f"Driver={SQL_DRIVER};"
        f"Server=tcp:{SQL_SERVER},1433;"
        f"Database={SQL_DATABASE};"
        f"Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"
    )
    if AUTH_MODE == "sql_auth":
        base += f"Uid={SQL_USER};Pwd={SQL_PASSWORD};"
    return base


def _get_access_token_struct() -> bytes:
    token = _credential.get_token("https://database.windows.net/.default").token
    token_bytes = token.encode("utf-16-le")
    return struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)


@contextmanager
def get_connection():
    """Yields a live pyodbc connection; closes it on exit regardless of outcome."""
    conn_str = _build_conn_str()
    if AUTH_MODE == "managed_identity":
        token_struct = _get_access_token_struct()
        conn = pyodbc.connect(conn_str, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct})
    else:
        conn = pyodbc.connect(conn_str)
    try:
        yield conn
    finally:
        conn.close()


def rows_to_dicts(cursor) -> list[dict]:
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]
