"""
FastAPI service exposing CRUD operations over:
  - pendingOnboardingRequest   (Read, and status transition on pickup)
  - reviewOnboardingRequest    (Create/Update the approval decision)
  - AuditLog                  (Create/Read processing history)

Run locally:
    uvicorn main:app --reload --port 8000

Environment variables required (see db.py):
    SQL_SERVER, SQL_DATABASE, AUTH_MODE, [SQL_USER, SQL_PASSWORD if sql_auth]
"""

from dotenv import load_dotenv
load_dotenv()  # loads variables from a .env file in the working directory, if present

from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query, status
from db import get_connection, rows_to_dicts
from adf import trigger_pipeline, get_pipeline_run_status
from schemas import (
    PendingRequest,
    ReviewUpdateRequest,
    ReviewRecord,
    AuditLogEntry,
    AuditLogRecord,
)

app = FastAPI(
    title="Onboarding Request Review API",
    description="CRUD layer over pendingOnboardingRequest, reviewOnboardingRequest, and AuditLog",
    version="1.0.0",
)


# --------------------------------------------------------------------------
# pendingOnboardingRequest — READ operations
# --------------------------------------------------------------------------

@app.get("/pending-requests", response_model=List[PendingRequest])
def list_pending_requests(
    status_filter: str = Query(default="Pending", alias="status"),
    limit: int = Query(default=50, le=500),
):
    """Fetch all requests with a given status (default: Pending)."""
    query = """
        SELECT TOP (?) *
        FROM pendingOnboardingRequest
        WHERE status = ?
        ORDER BY createdAt ASC
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, (limit, status_filter))
        return rows_to_dicts(cursor)


@app.get("/pending-requests/{request_id}", response_model=PendingRequest)
def get_pending_request(request_id: str):
    """Fetch a single request by its primary key."""
    query = "SELECT * FROM pendingOnboardingRequest WHERE requestId = ?"
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, (request_id,))
        rows = rows_to_dicts(cursor)
    if not rows:
        raise HTTPException(status_code=404, detail=f"requestId '{request_id}' not found")
    return rows[0]


# --------------------------------------------------------------------------
# reviewOnboardingRequest — CREATE / UPDATE / READ
# --------------------------------------------------------------------------

@app.put("/review-requests/{request_id}", response_model=ReviewRecord, status_code=status.HTTP_200_OK)
def upsert_review_status(request_id: str, payload: ReviewUpdateRequest):
    """
    Set the review decision for a request. Uses MERGE so this works whether
    or not a row already exists for this requestId (idempotent).
    """
    # Confirm the request actually exists before writing a decision for it
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT 1 FROM pendingOnboardingRequest WHERE requestId = ?", (request_id,)
        )
        if cursor.fetchone() is None:
            raise HTTPException(status_code=404, detail=f"requestId '{request_id}' not found")

        merge_query = """
            MERGE reviewOnboardingRequest AS target
            USING (SELECT ? AS requestId) AS source
            ON target.requestId = source.requestId
            WHEN MATCHED THEN
                UPDATE SET status = ?, remarks = ?, reviewedAt = GETDATE()
            WHEN NOT MATCHED THEN
                INSERT (requestId, status, remarks, reviewedAt)
                VALUES (?, ?, ?, GETDATE());
        """
        cursor.execute(
            merge_query,
            (request_id, payload.status, payload.remarks, request_id, payload.status, payload.remarks),
        )
        conn.commit()

        cursor.execute(
            "SELECT requestId, status, remarks, reviewedAt FROM reviewOnboardingRequest WHERE requestId = ?",
            (request_id,),
        )
        result = rows_to_dicts(cursor)

    return result[0]


@app.get("/review-requests/{request_id}", response_model=ReviewRecord)
def get_review_status(request_id: str):
    query = "SELECT requestId, status, remarks, reviewedAt FROM reviewOnboardingRequest WHERE requestId = ?"
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, (request_id,))
        rows = rows_to_dicts(cursor)
    if not rows:
        raise HTTPException(status_code=404, detail=f"No review record for requestId '{request_id}'")
    return rows[0]


@app.get("/review-requests", response_model=List[ReviewRecord])
def list_review_requests(status_filter: Optional[str] = Query(default=None, alias="status")):
    if status_filter:
        query = "SELECT requestId, status, remarks, reviewedAt FROM reviewOnboardingRequest WHERE status = ?"
        params = (status_filter,)
    else:
        query = "SELECT requestId, status, remarks, reviewedAt FROM reviewOnboardingRequest"
        params = ()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        return rows_to_dicts(cursor)


# --------------------------------------------------------------------------
# AuditLog — CREATE / READ
# --------------------------------------------------------------------------

@app.post("/audit-log", response_model=AuditLogRecord, status_code=status.HTTP_201_CREATED)
def create_audit_entry(entry: AuditLogEntry):
    insert_query = """
        INSERT INTO AuditLog (requestId, step, result, timestamp)
        OUTPUT INSERTED.id, INSERTED.requestId, INSERTED.step, INSERTED.result, INSERTED.timestamp
        VALUES (?, ?, ?, GETDATE())
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(insert_query, (entry.requestId, entry.step, entry.result))
        row = cursor.fetchone()
        conn.commit()
    columns = ["id", "requestId", "step", "result", "timestamp"]
    return dict(zip(columns, row))


@app.get("/audit-log/{request_id}", response_model=List[AuditLogRecord])
def get_audit_trail(request_id: str):
    query = "SELECT id, requestId, step, result, timestamp FROM AuditLog WHERE requestId = ? ORDER BY timestamp ASC"
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, (request_id,))
        rows = rows_to_dicts(cursor)
    if not rows:
        raise HTTPException(status_code=404, detail=f"No audit entries for requestId '{request_id}'")
    return rows


# --------------------------------------------------------------------------
# Azure Data Factory — trigger + status
# --------------------------------------------------------------------------

@app.post("/pipeline-runs/{request_id}", status_code=status.HTTP_202_ACCEPTED)
def trigger_pipeline_for_request(request_id: str):
    """
    Looks up the request's file reference and starts the ADF pipeline run.
    Only meant to be called for requests already marked Approved.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT status FROM reviewOnboardingRequest WHERE requestId = ?", (request_id,)
        )
        review_row = cursor.fetchone()
        if review_row is None:
            raise HTTPException(status_code=404, detail=f"No review record for '{request_id}'")
        if review_row[0] != "Approved":
            raise HTTPException(
                status_code=409,
                detail=f"requestId '{request_id}' is '{review_row[0]}', not Approved — pipeline not triggered",
            )

        cursor.execute(
            "SELECT fileName FROM pendingOnboardingRequest WHERE requestId = ?", (request_id,)
        )
        pending_row = cursor.fetchone()
        if pending_row is None or not pending_row[0]:
            raise HTTPException(status_code=422, detail="No fileName found for this request")
        file_name = pending_row[0]

    try:
        run_id = trigger_pipeline(file_name=file_name)
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=str(e))

    # Log the trigger for audit purposes
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO AuditLog (requestId, step, result, timestamp) VALUES (?, ?, ?, GETDATE())",
            (request_id, "adf_trigger", f"run_id={run_id}"),
        )
        conn.commit()

    return {"requestId": request_id, "runId": run_id, "status": "triggered"}


@app.get("/pipeline-runs/{run_id}/status")
def check_pipeline_run_status(run_id: str):
    try:
        run_status = get_pipeline_run_status(run_id)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Could not fetch run status: {e}")
    return {"runId": run_id, "status": run_status}


# --------------------------------------------------------------------------
# Health check
# --------------------------------------------------------------------------

@app.get("/health")
def health_check():
    try:
        with get_connection() as conn:
            conn.cursor().execute("SELECT 1")
        return {"status": "ok", "db": "reachable"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"DB unreachable: {e}")
